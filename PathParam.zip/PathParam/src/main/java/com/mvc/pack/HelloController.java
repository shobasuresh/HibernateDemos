package com.mvc.pack;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	
	@RequestMapping(value="/welcome/{uname}")
	public ModelAndView getVar(@PathVariable("uname") String nam)
	{
		
		ModelAndView m= new ModelAndView("WelcomePage");
		m.addObject("msg","Hello "+nam);
		return m;
	}
}
