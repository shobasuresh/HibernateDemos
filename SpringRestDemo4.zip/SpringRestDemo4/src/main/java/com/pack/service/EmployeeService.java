package com.pack.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Employee;
import com.pack.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository repository;
	
	
	public Employee saveEmployee(Employee employee)
	{
		 if (employee.getSalary()>5000f)
				employee.setInsScheme("A");
				 else
						employee.setInsScheme("B");
	
		  return repository.save(employee);
	}
	
	
	
	  public List<Employee> getEmployees() {
	  
	  return repository.findAll(); 
	  
	  }
	  
	  
	public Employee  getEmployeeById(long id)
	{
		 
		Optional<Employee> emp= repository.findById(id);
		if (emp.isPresent())
		 return emp.get();
		else
			return null;
}
	
	public  void deleteEmployee(Employee emloyee)
	{
		
		repository.delete(emloyee);
	}
	
}