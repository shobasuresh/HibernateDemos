package com.emp.pack;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	
	
	int eno;
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	String ename;
	
	 
	Address address;

}
