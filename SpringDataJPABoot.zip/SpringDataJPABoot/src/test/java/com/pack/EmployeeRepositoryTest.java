package com.pack;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.pack.model.Employee;
import com.pack.repository.EmployeeRepository;

/*
 * @DataJpaTest
 * 
 * @AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
 * 
 * public class EmployeeRepositoryTest {
 * 
 * @Autowired EmployeeRepository employeeRepository;
 * 
 * Employee e=new Employee("testabc", "testdesig");;
 * 
 * @Test
 * 
 * public void testCreateEmployee() { Employee emplo
 * =employeeRepository.save(e); System.out.println("in to");
 * assertNotEquals(emplo.getId(), 0); }
 * 
 * 
 * @Test public void testListEmployees() { List<Employee> emps =
 * (List<Employee>) employeeRepository.findAll(); //
 * assertThat(emps).size().equals(1); System.out.println("size "+emps.size());
 * assertEquals(emps.size(), 1); }
 * 
 * }
 */


@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(OrderAnnotation.class)
class EmployeeRepositoryTest {

 

    @Autowired
    EmployeeRepository employeeRepository;
    
    Employee e = new Employee("testabc","testdesign");
    
    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

 

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

 

    @BeforeEach
    void setUp() throws Exception {
    }

 

    @AfterEach
    void tearDown() throws Exception {
    }

 
    @Test
    @Order(2)
    public void testListEmployees()
    {
        List<Employee> emps=(List<Employee>) employeeRepository.findAll();
        System.out.println("size "+emps.size());
        assertEquals(1, emps.size());
    }
    
    
      @Test
      @Order(1)
      void testCreateEmployee()
      { 
          Employee emplo=employeeRepository.save(e);
          System.out.println("in to");
          assertNotEquals(0, emplo.getId()); 
          
      }
     
     
    
 

 

}