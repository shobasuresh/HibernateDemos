package com.pack.exception;

public class EmployeeNotFoundException extends Exception{
 
	public String toString()
	{
		
		return "Employee Id not found";
	}
}
