package com.pack.polaris;

 
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

class BeanSupport implements InitializingBean, DisposableBean {
 

	  @Override
	    public void afterPropertiesSet() throws Exception
	    {
		    
	        System.out.println("properties set");
	    }
	     
	    @Override
	    public void destroy() throws Exception 
	    {
	    	  System.out.println("Destroy method invoked");
	    }

	  
	 
	}