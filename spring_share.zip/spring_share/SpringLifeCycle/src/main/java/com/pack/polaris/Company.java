package com.pack.polaris;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Company extends BeanSupport{
	private String companyName;

	public String getCompanyName() {
		 
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
 
	}
