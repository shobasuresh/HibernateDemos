package com.fidelity.pack;

public class Wel {

	public String user;
	public String con;
	
    public String getCon() {
		return con;
	}

	public void setCon(String con) {
		this.con = con;
	}

	    
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	 public void init(){
		 con="Db Con";
	      System.out.println("Bean with id welbean has gone through init.");
	      
	   }
	 
	public void destroy(){
	      System.out.println("Bean with id welbean will destroy now.");
	   }
	   
	 
}
