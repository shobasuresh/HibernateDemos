package com.fidelity.pack;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	 
	public static void main(String[] args) {
		
	AbstractApplicationContext context = 
                new ClassPathXmlApplicationContext("CallBack.xml");

	
	  Welcome obj = (Welcome) context.getBean("welcomebean");
	  Wel obj1 = (Wel)  context.getBean("welbean"); 
	  obj.getMessage();
	  System.out.println(obj1.getUser()); 
	  context.registerShutdownHook();  
	    
	 
	}

}
