package com.jdbc.pack;

import java.util.List;

public interface AccountDao {
	public void createAccount(Account a);
	public void updateAccount(Account a);
	public void removeAccount(Account a);
	//public Account findAccount(Integer accountno);
	public List<Account> findAccount(Integer accountno,Double balance);
	public List<Account> findAll();

}

