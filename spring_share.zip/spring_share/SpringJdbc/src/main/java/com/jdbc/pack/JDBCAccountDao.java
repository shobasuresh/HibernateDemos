package com.jdbc.pack;

 
 
import java.util.List;

 import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

 
 
 
public class JDBCAccountDao  implements AccountDao{

	 
	//  @Autowired
	private DataSource ds;
 
	
	
	  public void setDs(DataSource ds) { 
		  this.ds = ds;
	  
	  }
	 
	 
	 
	
	 
	public void createAccount(Account a) {
		
	 
		JdbcTemplate insert = new JdbcTemplate(ds);
		insert.update("INSERT INTO Account(AccountNo,"+ "Balance) VALUES(?,?)",
	    		a.getAccountNo(),a.getBalance());
		 
	} 
 

	 
	public void updateAccount(Account a) {
		JdbcTemplate insert = new JdbcTemplate(ds);
	    insert.update("update account set balance =? "
	    		+ "where accountno=?",a.getBalance(),
	    		a.getAccountNo());
	    
	}

	 
	/*
	 * public Account findAccount(Integer accountno) { JdbcTemplate obj = new
	 * JdbcTemplate(ds);
	 * 
	 * Account a= obj.queryForObject("select * from " +
	 * "account where account_no=?", new Object[]{accountno}, new
	 * BeanPropertyRowMapper< Account> (Account.class));
	 * System.out.println("account "+a); return a; }
	 */
			 
				 
				 
	public List<Account> findAccount(Integer accountno,Double bal) {
		JdbcTemplate obj = new JdbcTemplate(ds);
			 
			 List<Account> a= obj.query("select * from "
			 		+ "account where accountno=? and balance=?",
			 		new Object[]{accountno,bal},
			 		new BeanPropertyRowMapper<Account>
			 		(Account.class));
			// System.out.println("account "+a);
		     return a;
		    }	  
	 
	
		    
	     
	
	public List<Account> findAll()
	{
		JdbcTemplate obj = new JdbcTemplate(ds);
		String sql = "SELECT accountno,balance from Account";
		//the class that each row should be mapped to
		
		List<Account> accounts  =obj.query(sql,new BeanPropertyRowMapper<Account>(Account.class));
		//System.out.println("getting "+accounts.get(0).getAccountNo());
		return accounts;
		 
	}
	public void removeAccount(Account a)
	{
		JdbcTemplate obj=new JdbcTemplate(ds);
		obj.update("delete from account where accountno=?",a.getAccountNo());
	}
	
	
	
	
	
	
	 
	
		 
}
