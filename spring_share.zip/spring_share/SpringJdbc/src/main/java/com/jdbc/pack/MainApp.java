package com.jdbc.pack;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class MainApp {

	
	public static void main(String[] args) {
		 ApplicationContext ac = new ClassPathXmlApplicationContext("SqlBean.xml");
	        
         JDBCAccountDao acct = (JDBCAccountDao)ac.getBean("accountDao");
		 Account a = new Account(45,4500.0);
 	     Account a1 = new Account(23,5600.0);
 		 Account a2 = new Account(23,7500.0);
    	//acct.createAccount(a1);
 		//	//acct.createAccount(a1);
 		 //  acct.updateAccount(a2);
 		// acct.removeAccount(a1); 
		
		/*
		 * Account a3=acct.findAccount(35);
		 * System.out.println("From a3 "+a3.getBalance()+"account no "+a3.getAccountNo()
		 * );
		 */
		 
		 
		
		
		  List<Account> a3=acct.findAccount(23,7500d);
		  if (a3.size()==0)
		  System.out.println("No matching row");
		  else for (Account obj:a3)
		  System.out.println(obj.getAccountNo()+" "+obj.getBalance());
		 
		  
		  
		  
		  
	
	  List<Account> ac1=acct.findAll(); for (Account o:ac1)
	  System.out.println(o.getAccountNo()+" "+o.getBalance());
	 
		 
		 
		 
		   
 // acct.removeAccount(a1); 

}
}