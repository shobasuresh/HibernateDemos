package com.jdbc.pack;

public class Account {
	
	public Integer getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Integer accountNo) {
		this.accountNo = accountNo;
	}

	private Integer accountNo;
	 
	 
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	private double balance;
	
	 
	public Account()
	{
		
	}
	public Account(Integer ac,double bal)
	{
		accountNo=ac;
		balance=bal;
	}
	}
