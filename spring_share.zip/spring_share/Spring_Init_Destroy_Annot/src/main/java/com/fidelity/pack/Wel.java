package com.fidelity.pack;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Wel {

	String user;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	@PostConstruct
	 public void init(){
	      System.out.println("Bean with id welbean has gone through init.");
	   }
	
	@PreDestroy
	   public void destroy(){
	      System.out.println("Bean with id welbean will destroy now.");
	   }
}
