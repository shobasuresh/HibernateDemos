package com.employee.pack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		 
		  ApplicationContext appContext = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		 
		  Country countryObj3 = (Country) appContext.getBean("countryObj");
		  Country countryObj4 = (Country) appContext.getBean("countryObj");
		  
		  
		  Country countryObj1 = (Country) appContext.getBean("bean2");	
		  Country countryObj2 = (Country) appContext.getBean("bean2");	
			
			   
			 
		  
		  System.out.println(countryObj3);
		  System.out.println(countryObj4);
		  
		 }
		}


