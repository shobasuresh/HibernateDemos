package com.employee.pack;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

 
@Configuration
 
 
	public class ApplicationConfiguration {
	 
  
	 @Lazy 
	 @Scope("prototype")
	 @Bean(name="countryObj")
	
	 public Country getCountry()
	 {
	  return new Country("India");
	 }
	 
	 
	 @Bean(name="bean2")
		
	 public Country getCountry2()
	 {
	  return new Country("Srilanka");
	 }
	 
	}