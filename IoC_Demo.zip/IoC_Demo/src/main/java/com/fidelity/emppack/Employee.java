package com.fidelity.emppack;

public class Employee {
	
	int id;
	String name;
	Address address;
	
	
	public Address getAddress() {
		return address;
	}

	  public Employee(String nam1,int ide1,Address addr1) {
		  System.out.println("into this"); 
		  name=nam1; id=ide1; address=addr1;
		  
		  }
			
			 
		
	
	public int getId() {
		return id;
	}

	
	public String getName() {
		return name;
	}

	 

}
