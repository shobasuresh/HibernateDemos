package com.fidelity.emppack;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class EmpMain {
	
	public static void main(String args[])
	
	{
		
		//XmlBeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("Emp.xml"));
		ApplicationContext beanFactory=new ClassPathXmlApplicationContext("Emp.xml");
		Employee myBean = (Employee) beanFactory.getBean("fidelitypay");
	 
	 
		//System.out.println(myBean.getId());
		System.out.println(myBean.getName());
		System.out.println(myBean.getAddress().getCity());
		
	}

}
